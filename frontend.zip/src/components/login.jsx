import { useState } from "react"
import { useNavigate } from "react-router-dom"

const Loginpage = () =>{
  const[username,setusername]=useState('')
  const[password,setPassword]=useState('')
  const navigate = useNavigate();
  const handlelogin = async(event)=>{
    event.preventDefault()
        
    let headersList = {
      Accept: "*/*",
      "Content-Type": "application/json",
    };


      const bodyHeaders = JSON.stringify({
        username: username,
        password: password
      });

      try {
        let response = await fetch('http://localhost:3000/api/login', {
          method: "POST",
          body: bodyHeaders,
          headers:headersList,
        });
        let code = await response.json()
        if(code.code == 201){
          navigate('/homepage')
        }
        else(
          alert("wrong password")
        )
      }

      catch(error){
   console.log(error)
      }
    

  }

    return(
    <div style={{marginLeft:"600px"}}>
      <div>
        <h1 >Username</h1>
        <input type="text" onChange={(e)=>setusername(e.target.value)}/>
        <h1>Password</h1>
        <input type="password" onChange={(e)=>setPassword(e.target.value)}/>
       
      </div>
      <button onClick={handlelogin}>Login</button>
    </div>)
}

export default Loginpage