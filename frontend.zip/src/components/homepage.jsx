

const Homepage = ()=>{
  return(
    <div>
        <div>Home page</div>
    </div>
  )
}

export default Homepage